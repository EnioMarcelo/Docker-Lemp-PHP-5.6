clear && docker stop  $(docker ps -a -q) && docker rm  $(docker ps -a -q) && docker volume prune -f


docker-compose up -d 


docker-compose ps



docker ps -a
